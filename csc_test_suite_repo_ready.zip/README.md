# CSC Test Suite — Independent, Runnable Validation

This repository lets anyone — with no affiliation, no special access, and
no need to trust the author's word — independently verify the empirical
claims in Shawn Pruyn's Chronostatic Cyclic Cosmology (CSC) papers, using
only public data and fully visible code.

## The core transparency claim, stated plainly

**No parameter in any CSC equation here is fitted to the test it is being
checked against.** Every constant (0.242844, -0.473464, 0.8513, 0.4466,
and others as more modules are added) is hard-coded directly from the
published papers, in the model definition files, before the data is ever
loaded.

**→ See [`docs/PARAMETER_ACCOUNTING.md`](docs/PARAMETER_ACCOUNTING.md) for
a line-by-line table showing exactly what is held fixed vs. what varies
per galaxy in each model (baryons-only, MOND/RAR, and CSC), and exactly
how to verify it yourself in the code.** This is the single most important
document in this repo for understanding why the comparison is fair: all
three models use zero per-galaxy free parameters, taking only each
galaxy's own measured quantities (gas/disk/bulge velocity, HI radius,
baryonic mass) as input to one fixed global formula.

You can verify the no-tuning claim yourself in under a minute per module:

1. Open `models.py` in any module folder.
2. Find the constants at the top — they are plain numbers, not fitted
   variables, not read from a config file that gets adjusted, not derived
   from the test data anywhere in the code.
3. Open the corresponding run script (e.g. `run_sparc_test.py`) and confirm
   the constants are never modified, refit, or optimized against the
   observational data at any point before the comparison statistics are
   computed.

If you find a place where this is not true — where a constant is silently
adjusted to improve the fit — that is a real bug and you should open an
issue. Reporting that kind of error is exactly what this repository is
for.

## What "independent" means here

- All data is the original public dataset (SPARC database, Pantheon+SH0ES,
  DESI BAO), unmodified except for file format conversion. Each module's
  README states exactly where to download a fresh copy yourself.
- The comparison models (MOND/RAR, flat ΛCDM) are standard, well-documented
  implementations, not strawman versions built to lose.
- Where this code's results differ from the originally published numbers
  (e.g. a different sample size due to lost intermediate working files),
  this is stated explicitly in the relevant module's README rather than
  hidden or quietly adjusted to match.

## Modules

| Module | Tests | Status |
|---|---|---|
| `module1_sparc/` | CSC fixed law vs. MOND/RAR vs. baryons-only, SPARC rotation curves | Complete — see module README |
| `module2_dwarf/` | Dwarf-galaxy running exponent q(M) ≈ (π/100)·log(M) + b | In progress |
| `module3_horizon/` | CSC running horizon geometry vs. ΛCDM, Pantheon+SH0ES + DESI BAO | In progress |

Each module folder has its own README with exact run instructions, exact
data-source links, and an honest statement of what is and isn't yet
independently confirmed.

## How to verify this isn't just trust-me science

Don't take any number in any paper at face value, including this one's.
Instead:

1. Download the public data yourself, from the original sources linked in
   each module README (not from this repo, if you want a fully independent
   copy).
2. Read the model code before running it. The equations should match the
   papers exactly — check them side by side.
3. Run it. Compare what comes out to what's claimed.
4. If something doesn't match, that's worth knowing, and the module READMEs
   already document the one place (Module 1's sample size) where this
   repo's own honest result differs from the originally published number.

## Open issues / known limitations

- Module 1's sample (171 galaxies) differs from the original paper's
  reported sample (155 galaxies) because the exact original exclusion
  criteria were not preserved (see `module1_sparc/README.md` for full
  detail). The qualitative ranking (CSC < MOND < baryons-only in RMS)
  holds on both samples.
- The geometric origin of the 4/π projection factor used in the horizon
  module (Module 3) is not yet derived from independent first principles;
  it is currently an empirical match to within 0.03% of the fitted
  diagnostic value. This is stated openly in that module's documentation
  rather than presented as a closed derivation.

## Papers this code tests

- Pruyn, S. M. (2026). *The CSC Galaxy Equation: A Fixed-Law SPARC Test of
  Disk Galaxy Rotation Curves.* Zenodo. DOI: 10.5281/zenodo.20685767.
- Pruyn, S. M. (2026). *No Hidden Mass Required: A Fixed-Law and
  Running-Exponent SPARC Test of Disk and Dwarf Galaxy Rotation Curves.*
  Zenodo.
- Pruyn, S. M. (2026). *Running Horizon Boundary Redshift Geometry.* Zenodo.

## Contact

Shawn M. Pruyn — shawnpruyn77@gmail.com — ORCID 0009-0008-7165-4155
