# Module 1: SPARC Rotation Curve Test — CSC vs. MOND/RAR vs. Baryons-only

## What this tests

Whether Pruyn's CSC fixed-law equation (from "No Hidden Mass Required",
2026) — a single, globally-fixed formula with NO per-galaxy tuning —
predicts SPARC disk-galaxy rotation curves better than:
1. A baryons-only Newtonian prediction (no dark matter, no modification)
2. One standard MOND/RAR implementation (McGaugh, Lelli & Schombert 2016)

## Getting the data (if you don't already have it)

This repo already includes the two files you need in `../data/`, copied
from the public SPARC database. If you want to fetch them yourself, fresh,
to verify nothing was altered:

1. Go to **astroweb.case.edu/SPARC** (Lelli, McGaugh & Schombert 2016,
   *The Astronomical Journal*, 152, 157 — DOI: 10.3847/0004-6256/152/6/157,
   arXiv:1606.09251).
2. Download:
   - **Table 1** (galaxy sample table — distances, inclinations, luminosities,
     R_HI, M_HI, V_flat, quality flag Q) → save as `SPARC_galaxy_table.mrt`
   - **Table 2 / Mass Models** (per-galaxy, per-radius rotation curve points:
     R, V_obs, e_V_obs, V_gas, V_disk, V_bul) → save as `SPARC_mass_models.mrt`
3. Place both files in `../data/` (or update the `DATA_DIR` path at the
   top of `run_sparc_test.py`).

Both files are public domain research data, free to download, no login
or institutional access required.

## How to run it

```
cd module1_sparc
python3 run_sparc_test.py
```

Requires Python 3 with `numpy` and `pandas` installed. No internet access
needed — the data files are already in `../data/`.

## What you should see

```
Model                    RMS (km/s)       R^2
---------------------------------------------
Baryons only                  43.90     0.749
CSC fixed law                 35.32     0.838
MOND / RAR                    41.49     0.776
```

Lower RMS = better fit. Higher R² = better fit. **CSC beats both
alternatives on this independently-built sample.**

## Important honesty note on sample size

This pipeline builds its own analysis sample directly from the public
SPARC files, applying one explicit cut: `RHI > 0` (the galaxy must have
a usable HI radius). This yields **171 galaxies / 3346 points**.

The original paper reports **155 galaxies / 3207 points**. The original
analysis script that produced that exact sample no longer exists (working
files were deleted to save disk space during the original research), and
the precise additional exclusion criteria could not be recovered. Several
plausible candidates (inclination cuts, Vflat-reported cuts, Q=3 exclusion)
were tested and none landed exactly on 155/3207, so none were imposed
artificially just to match the published number.

**This is reported as what it is: an independent reproduction with its
own honestly-stated sample, not a byte-for-byte replay of the original
analysis.** The fact that an independently-built sample of 171 galaxies
(16 more than the original) still shows the same ranking — CSC beats
MOND beats baryons-only — is, if anything, a more convincing result than
an exact replay would be, because it shows the conclusion isn't sensitive
to the exact 16-galaxy difference.

## What's NOT tuned in this pipeline

The CSC equation's four constants (amplitude exponent 0.242844, log-amplitude
-0.473464, profile exponent 0.8513, transition constant 0.4466) are hard-coded
in `models.py` exactly as published. They are never refit to this sample.
This is the core methodological claim under test: one global law, applied
identically everywhere, with no galaxy-by-galaxy adjustment.

## Files

- `parse_sparc.py` — parses the two raw SPARC MRT files into pandas DataFrames
- `models.py` — defines all three models (baryons-only, CSC, MOND/RAR) and the RMS/R² statistics
- `run_sparc_test.py` — main script; builds the sample, runs all three models, prints results
- `sparc_results_full.csv` — generated on each run; per-point predictions from all three models, for independent spot-checking

## Verifying the parser yourself

If you don't trust the column parsing, open `../data/SPARC_galaxy_table.mrt`
and `../data/SPARC_mass_models.mrt` in a text editor and manually check a
few rows against `parse_sparc.py`'s output. The parser uses whitespace
tokenization (not fixed byte columns) because the byte-column spec printed
in the files' own headers does not match the actual data row lengths in
these particular file copies — this was verified by checking that every
row produces exactly the documented number of fields with physically sane
values (see comments in `parse_sparc.py` for details).
