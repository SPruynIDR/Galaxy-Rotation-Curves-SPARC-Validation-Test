"""
Parser for SPARC database files (Lelli, McGaugh & Schombert 2016, AJ 152, 157).

Reads the two public SPARC tables in their native fixed-width MRT format:
  - SPARC_galaxy_table.mrt  (Table1.mrt)   -> one row per galaxy
  - SPARC_mass_models.mrt   (datafile2.txt) -> one row per rotation-curve point

No external SPARC-specific library is required; this uses only the byte
column specifications printed in the header of each MRT file.
"""

import pandas as pd
import numpy as np
import io


def parse_galaxy_table(path):
    """
    Parse the SPARC galaxy-level summary table (Table1.mrt).

    NOTE ON FORMAT: the byte-column spec printed in this file's own header
    (columns 1-113) does not match the actual data rows, which run to 131
    characters per line in the copy used here. Rather than trust the header's
    byte offsets, this parser splits each data line on whitespace. This is
    safe for this file because every one of the 19 documented fields is
    populated on every row (verified: all 175 rows produce exactly 19
    whitespace-separated tokens, with values landing in physically sane
    ranges -- distances 0.98-127.8 Mpc, inclination 15-90 deg, Q in {1,2,3}).

    The 19 fields, in order, are:
      Galaxy, T, D, e_D, f_D, Inc, e_Inc, L36, e_L36, Reff,
      SBeff, Rdisk, SBdisk, MHI, RHI, Vflat, e_Vflat, Q, Ref
    """
    names = [
        "Galaxy", "T", "D", "e_D", "f_D", "Inc", "e_Inc",
        "L36", "e_L36", "Reff", "SBeff", "Rdisk", "SBdisk",
        "MHI", "RHI", "Vflat", "e_Vflat", "Q", "Ref"
    ]

    with open(path, "r", encoding="latin-1") as f:
        lines = f.readlines()

    sep_idx = [i for i, l in enumerate(lines) if l.strip().startswith("---")]
    data_start = sep_idx[-1] + 1

    data_lines = [l.rstrip("\r\n") for l in lines[data_start:] if l.strip() != ""]

    rows = []
    skipped = []
    for line in data_lines:
        toks = line.split()
        if len(toks) != len(names):
            skipped.append(line)
            continue
        rows.append(toks)

    if skipped:
        print(f"WARNING: {len(skipped)} galaxy-table lines did not tokenize "
              f"into {len(names)} fields and were skipped:")
        for l in skipped:
            print("  ", l)

    df = pd.DataFrame(rows, columns=names)

    numeric_cols = ["T", "D", "e_D", "f_D", "Inc", "e_Inc", "L36", "e_L36",
                     "Reff", "SBeff", "Rdisk", "SBdisk", "MHI", "RHI",
                     "Vflat", "e_Vflat", "Q"]
    for c in numeric_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    return df


def parse_mass_models(path):
    """
    Parse the SPARC per-point mass model table (datafile2.txt).

    Fields, in order (10 per row, confirmed by whitespace tokenization
    across all 3391 data rows, including rows with negative Vgas values
    such as DDO064's inner points):
      ID, D, R, Vobs, e_Vobs, Vgas, Vdisk, Vbul, SBdisk, SBbul
    """
    names = ["ID", "D", "R", "Vobs", "e_Vobs", "Vgas", "Vdisk", "Vbul",
              "SBdisk", "SBbul"]

    with open(path, "r", encoding="latin-1") as f:
        lines = f.readlines()

    sep_idx = [i for i, l in enumerate(lines) if l.strip().startswith("---")]
    data_start = sep_idx[-1] + 1

    data_lines = [l.rstrip("\r\n") for l in lines[data_start:] if l.strip() != ""]

    rows = []
    skipped = []
    for line in data_lines:
        toks = line.split()
        if len(toks) != len(names):
            skipped.append(line)
            continue
        rows.append(toks)

    if skipped:
        print(f"WARNING: {len(skipped)} mass-model lines did not tokenize "
              f"into {len(names)} fields and were skipped:")
        for l in skipped:
            print("  ", l)

    df = pd.DataFrame(rows, columns=names)

    numeric_cols = ["D", "R", "Vobs", "e_Vobs", "Vgas", "Vdisk", "Vbul",
                     "SBdisk", "SBbul"]
    for c in numeric_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    return df


if __name__ == "__main__":
    import sys
    gal = parse_galaxy_table("/home/claude/csc_test_suite/data/SPARC_galaxy_table.mrt")
    mm = parse_mass_models("/home/claude/csc_test_suite/data/SPARC_mass_models.mrt")

    print(f"Galaxy table: {len(gal)} galaxies")
    print(gal.head(10).to_string())
    print()
    print(f"Mass models: {len(mm)} rotation curve points across {mm['ID'].nunique()} galaxies")
    print(mm.head(10).to_string())
