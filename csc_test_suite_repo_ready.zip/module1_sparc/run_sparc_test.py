"""
Main SPARC head-to-head test: CSC fixed law vs. MOND/RAR vs. baryons-only.

Run:
    python3 run_sparc_test.py

WHAT THIS IS:
This is an INDEPENDENT reproduction built from scratch against the public
SPARC database, using the equations and global constants exactly as
published in Pruyn's "No Hidden Mass Required" paper. It is not a replay
of the author's original analysis script (that script no longer exists --
intermediate working files were deleted during the original work to save
disk space). Sample selection here is stated explicitly below and is the
only cut applied: RHI > 0 (a usable HI radius was reported), plus dropping
any row with a missing essential value.

This independent build yields 171 galaxies / 3346 rotation-curve points,
compared to the 155 galaxies / 3207 points reported in the original paper.
The exact additional exclusion criteria used in the original analysis were
not preserved and could not be recovered, so this tool does not claim to
reproduce the original sample exactly. What it tests is the same global
law, the same fixed constants (not refit), against an independently-built
sample drawn from the same public source -- and reports its own numbers
honestly, whatever they turn out to be.

Data required (already included in ../data/):
    SPARC_galaxy_table.mrt   (Lelli, McGaugh & Schombert 2016, Table 1)
    SPARC_mass_models.mrt    (same paper, mass models / datafile2.txt)

Both files are the public SPARC database, unmodified except for being
saved as plain text.
"""

import os
import sys

import numpy as np
import pandas as pd
from parse_sparc import parse_galaxy_table, parse_mass_models
from models import (
    v_baryon_squared, csc_v_predicted_squared, csc_v_extra_squared,
    mond_v_predicted_squared, rms, r_squared
)

DATA_DIR = "../data"


def _check_data_files():
    gal_path = f"{DATA_DIR}/SPARC_galaxy_table.mrt"
    mm_path = f"{DATA_DIR}/SPARC_mass_models.mrt"
    missing = [p for p in (gal_path, mm_path) if not os.path.isfile(p)]
    if missing:
        print("ERROR: required SPARC data file(s) not found:")
        for p in missing:
            print(f"   {p}")
        print()
        print("See README.md, section 'Getting the data', for exact")
        print("download instructions (astroweb.case.edu/SPARC).")
        sys.exit(1)


def build_sample(quality_max=None, verbose=True):
    """
    Build the per-point analysis table: merge mass models with galaxy-level
    RHI and M_bar, apply the RHI-valid cut (RHI > 0), and optionally a
    quality cut (Q <= quality_max).

    Returns a DataFrame with one row per rotation-curve point, including
    Vobs, Vgas, Vdisk, Vbul, R, RHI, Mbar (in solar masses), and Q.
    """
    gal = parse_galaxy_table(f"{DATA_DIR}/SPARC_galaxy_table.mrt")
    mm = parse_mass_models(f"{DATA_DIR}/SPARC_mass_models.mrt")

    # Stellar + gas mass, per Pruyn's papers: M* = 0.5 * L[3.6] (in 1e9 Lsun
    # units becomes 1e9 Msun), Mbar = M* + 1.33*MHI (1.33 factor already
    # baked into SPARC's reported MHI per the SPARC docs -- but the CSC
    # papers apply it explicitly; we follow the CSC papers' stated formula
    # exactly, using the galaxy table's MHI column directly).
    gal = gal.copy()
    gal["Mstar_1e9"] = 0.5 * gal["L36"]
    gal["Mbar_1e9"] = gal["Mstar_1e9"] + 1.33 * gal["MHI"]
    gal["Mbar_solar"] = gal["Mbar_1e9"] * 1.0e9

    keep_cols = ["Galaxy", "RHI", "Q", "Mbar_solar", "Vflat", "D"]
    gal_small = gal[keep_cols].rename(columns={"Galaxy": "ID"})

    merged = mm.merge(gal_small, on="ID", how="left")

    n_before = len(merged)
    n_galaxies_before = merged["ID"].nunique()

    # RHI-valid cut: RHI must be a positive number (some galaxies in the
    # table have RHI = 0.00, meaning no usable HI radius was reported).
    merged = merged[merged["RHI"] > 0].copy()

    if quality_max is not None:
        merged = merged[merged["Q"] <= quality_max].copy()

    # Drop rows with any missing essential value
    essential = ["Vobs", "Vgas", "Vdisk", "Vbul", "R", "RHI", "Mbar_solar"]
    merged = merged.dropna(subset=essential).copy()

    n_after = len(merged)
    n_galaxies_after = merged["ID"].nunique()

    if verbose:
        print(f"Sample build: {n_galaxies_before} galaxies / {n_before} points "
              f"before cuts -> {n_galaxies_after} galaxies / {n_after} points "
              f"after RHI-valid{' + Q<=' + str(quality_max) if quality_max else ''} cut")

    return merged


def run_models(df):
    """
    Given the analysis DataFrame, compute predicted V^2 under all three
    models and return per-point results plus summary statistics.
    """
    Vobs = df["Vobs"].values
    Vgas = df["Vgas"].values
    Vdisk = df["Vdisk"].values
    Vbul = df["Vbul"].values
    R = df["R"].values
    RHI = df["RHI"].values
    Mbar = df["Mbar_solar"].values

    Vbar2 = v_baryon_squared(Vgas, Vdisk, Vbul)
    Vbar2 = np.clip(Vbar2, 0, None)
    Vbar_pred = np.sqrt(Vbar2)

    Vcsc2_pred = csc_v_predicted_squared(Vgas, Vdisk, Vbul, R, RHI, Mbar)
    Vcsc2_pred = np.clip(Vcsc2_pred, 0, None)
    Vcsc_pred = np.sqrt(Vcsc2_pred)

    Vmond2_pred = mond_v_predicted_squared(Vgas, Vdisk, Vbul, R)
    Vmond2_pred = np.clip(Vmond2_pred, 0, None)
    Vmond_pred = np.sqrt(Vmond2_pred)

    results = df.copy()
    results["Vbar_pred"] = Vbar_pred
    results["Vcsc_pred"] = Vcsc_pred
    results["Vmond_pred"] = Vmond_pred

    summary = {
        "N_galaxies": df["ID"].nunique(),
        "N_points": len(df),
        "baryons_only": {
            "RMS": rms(Vobs, Vbar_pred),
            "R2": r_squared(Vobs, Vbar_pred),
        },
        "CSC_fixed_law": {
            "RMS": rms(Vobs, Vcsc_pred),
            "R2": r_squared(Vobs, Vcsc_pred),
        },
        "MOND_RAR": {
            "RMS": rms(Vobs, Vmond_pred),
            "R2": r_squared(Vobs, Vmond_pred),
        },
    }

    return results, summary


def print_summary(summary, label=""):
    print()
    print(f"=== {label} ===" if label else "=== Results ===")
    print(f"Sample: {summary['N_galaxies']} galaxies, {summary['N_points']} rotation curve points")
    print()
    print(f"{'Model':<20}{'RMS (km/s)':>15}{'R^2':>10}")
    print("-" * 45)
    for name, key in [("Baryons only", "baryons_only"),
                       ("CSC fixed law", "CSC_fixed_law"),
                       ("MOND / RAR", "MOND_RAR")]:
        s = summary[key]
        print(f"{name:<20}{s['RMS']:>15.2f}{s['R2']:>10.3f}")


if __name__ == "__main__":
    _check_data_files()

    print("=" * 70)
    print("CSC vs. MOND/RAR vs. Baryons-only -- SPARC Rotation Curve Test")
    print("=" * 70)
    print()
    print("NOTE: This is an independent build against the public SPARC")
    print("database. Sample size will differ from the original paper's")
    print("155 galaxies / 3207 points (see module docstring for why).")
    print("The global CSC constants below are NOT refit -- they are used")
    print("exactly as published, applied identically to every galaxy.")
    print()
    print("Loading SPARC data and building RHI-valid sample...")
    df = build_sample(quality_max=None)

    print()
    print("Running all three models on the full RHI-valid sample...")
    results, summary = run_models(df)
    print_summary(summary, label="Full RHI-valid sample (all quality flags)")

    print()
    print("Running on the Q=1 (high quality) subsample only...")
    df_q1 = build_sample(quality_max=1)
    results_q1, summary_q1 = run_models(df_q1)
    print_summary(summary_q1, label="Q=1 high-quality subsample")

    # Save full results table for inspection
    results.to_csv("/home/claude/csc_test_suite/module1_sparc/sparc_results_full.csv", index=False)
    print()
    print("Full per-point results saved to sparc_results_full.csv")
    print()
    print("=" * 70)
    print("BOTTOM LINE (independent build, real public SPARC data):")
    print(f"  Baryons only:   RMS = {summary['baryons_only']['RMS']:.2f} km/s, R^2 = {summary['baryons_only']['R2']:.3f}")
    print(f"  MOND / RAR:     RMS = {summary['MOND_RAR']['RMS']:.2f} km/s, R^2 = {summary['MOND_RAR']['R2']:.3f}")
    print(f"  CSC fixed law:  RMS = {summary['CSC_fixed_law']['RMS']:.2f} km/s, R^2 = {summary['CSC_fixed_law']['R2']:.3f}")
    print("=" * 70)
