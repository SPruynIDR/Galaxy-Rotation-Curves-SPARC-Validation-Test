"""
Model definitions for the SPARC rotation-curve head-to-head test:
  1. Baryons-only (Newtonian, no dark matter, no modification)
  2. CSC fixed-law equation (Pruyn 2026, Papers II)
  3. MOND / Radial Acceleration Relation (McGaugh, Lelli & Schombert 2016)

All three are evaluated on the same data with the same RMS/R^2 procedure
so the comparison is apples-to-apples.
"""

import numpy as np


# ---------------------------------------------------------------------------
# 1. Baryonic velocity (shared by all models -- this is just Newtonian
#    gravity from the observed gas + disk + bulge mass distribution)
# ---------------------------------------------------------------------------

def v_baryon_squared(Vgas, Vdisk, Vbul):
    """
    V_bar^2 = V_disk^2 + V_bul^2 + V_gas*|V_gas|

    The Vgas*|Vgas| form (rather than Vgas^2) preserves the sign convention
    used in the SPARC mass models, where Vgas can be negative in the inner
    parts of some galaxies (it represents a signed contribution to the
    force balance, not just a magnitude).
    """
    return Vdisk**2 + Vbul**2 + Vgas * np.abs(Vgas)


# ---------------------------------------------------------------------------
# 2. CSC fixed-law equation (from "No Hidden Mass Required", Eq. 41)
# ---------------------------------------------------------------------------

def csc_F(x, a=0.8513, x0=0.4466):
    """Dimensionless H I-scaled radial activation profile."""
    return x**a / (x**a + x0**a)


def csc_v_extra_squared(R, RHI, Mbar_solar,
                          log_amp=-0.473464, mass_exp=0.242844,
                          a=0.8513, x0=0.4466):
    """
    V_CSC^2 = [10^log_amp * Mbar^mass_exp * F(R/RHI)]^2

    This is the directly-fitted SPARC form from the CSC papers (Eq. 41 of
    "No Hidden Mass Required"), with the global constants exactly as
    published: log_amp = -0.473464, mass_exp = 0.242844, a = 0.8513,
    x0 = 0.4466. These are NOT refit here -- they are taken as given,
    frozen global constants, applied to every galaxy with no per-galaxy
    adjustment, which is the central methodological claim under test.
    """
    x = R / RHI
    amp = (10.0**log_amp) * (Mbar_solar**mass_exp)
    Vmiss = amp * csc_F(x, a=a, x0=x0)
    return Vmiss**2


def csc_v_predicted_squared(Vgas, Vdisk, Vbul, R, RHI, Mbar_solar):
    """V_pred^2 = V_bar^2 + V_CSC^2"""
    return v_baryon_squared(Vgas, Vdisk, Vbul) + csc_v_extra_squared(R, RHI, Mbar_solar)


# ---------------------------------------------------------------------------
# 3. MOND / Radial Acceleration Relation
#    (McGaugh, Lelli & Schombert 2016, PRL 117, 201101)
#
#    g_obs = g_bar / (1 - exp(-sqrt(g_bar/g_dagger)))
#    with g_dagger = 1.20e-10 m/s^2 (the RAR/MOND acceleration scale).
#
#    This is the standard simple interpolating function (the "RAR" form),
#    used here as one specific, well-documented MOND/RAR implementation,
#    consistent with how the CSC papers describe their own MOND benchmark.
# ---------------------------------------------------------------------------

G_DAGGER = 1.20e-10  # m/s^2, McGaugh et al. 2016

KPC_TO_M = 3.0856775814913673e19
KMS_TO_MS = 1.0e3


def mond_v_predicted_squared(Vgas, Vdisk, Vbul, R_kpc):
    """
    Apply the RAR interpolating function to the baryonic acceleration to
    get the MOND-predicted total circular velocity squared, in (km/s)^2.
    """
    Vbar2_kms2 = v_baryon_squared(Vgas, Vdisk, Vbul)  # (km/s)^2
    Vbar2_kms2 = np.clip(Vbar2_kms2, 0, None)

    R_m = R_kpc * KPC_TO_M
    Vbar_ms2 = Vbar2_kms2 * (KMS_TO_MS**2)

    with np.errstate(divide="ignore", invalid="ignore"):
        g_bar = Vbar_ms2 / R_m  # m/s^2 (this is V^2/R, the centripetal accel)

    g_bar_safe = np.where(g_bar > 0, g_bar, np.nan)
    x = np.sqrt(g_bar_safe / G_DAGGER)
    denom = 1.0 - np.exp(-x)
    # avoid divide by zero at g_bar -> 0
    denom = np.where(denom > 1e-10, denom, np.nan)
    g_obs = g_bar_safe / denom

    V_obs_ms2 = g_obs * R_m
    V_obs_kms2 = V_obs_ms2 / (KMS_TO_MS**2)

    # Where g_bar was zero or negative, MOND prediction reduces to baryonic
    V_obs_kms2 = np.where(np.isnan(V_obs_kms2), Vbar2_kms2, V_obs_kms2)

    return V_obs_kms2


# ---------------------------------------------------------------------------
# Shared statistics
# ---------------------------------------------------------------------------

def rms(observed, predicted):
    resid = observed - predicted
    return np.sqrt(np.nanmean(resid**2))


def r_squared(observed, predicted):
    resid = observed - predicted
    ss_res = np.nansum(resid**2)
    ss_tot = np.nansum((observed - np.nanmean(observed))**2)
    return 1.0 - ss_res / ss_tot
