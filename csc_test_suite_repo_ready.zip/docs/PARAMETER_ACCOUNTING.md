# Parameter Accounting: What's Fixed vs. What's Allowed to Vary

This document exists because a head-to-head RMS/R² number, by itself,
doesn't tell you whether a model is doing something structurally different
from its competitors or just curve-fitting harder. This page makes that
distinction explicit and checkable, line by line, against the actual code.

## The question this answers

When a model's predicted rotation curve matches an observed one well, there
are two very different reasons that could be true:

1. **The model has a fixed mathematical form, and the same global numbers,
   applied identically to every single galaxy** — meaning the only inputs
   that change from galaxy to galaxy are *measured quantities* (the
   galaxy's own gas, disk, bulge velocity contributions; its own HI radius)
   — not free parameters tuned per galaxy to make that galaxy's curve fit.

2. **The model has one or more free parameters that get re-fit, re-tuned,
   or re-optimized for each individual galaxy** to make that galaxy's
   curve match. In this case, a good fit mostly tells you the model has
   enough flexibility to match almost any shape, not that the model's
   physical mechanism is correct.

Both can produce a good-looking plot. They are not the same kind of
evidence.

## What each model in this repo actually does, per galaxy

| Model | Per-galaxy free parameters | What varies galaxy-to-galaxy |
|---|---|---|
| **Baryons only** | **0** | Only measured quantities: V_gas(R), V_disk(R), V_bul(R) — SPARC's own observed baryonic velocity contributions. No fitting happens at all; this is pure Newtonian gravity from the visible matter. |
| **MOND/RAR** (this repo's implementation) | **0** | Same measured V_gas, V_disk, V_bul, plus the radius R. The single constant g† = 1.20×10⁻¹⁰ m/s² is a *global* constant, identical for every galaxy — never refit per galaxy in this code. |
| **CSC fixed law** | **0** | Same measured V_gas, V_disk, V_bul, plus each galaxy's own measured R_HI and M_bar (computed from each galaxy's own measured L[3.6] and M_HI). The four CSC constants (amplitude exponent 0.242844, log-amplitude -0.473464, profile exponent 0.8513, transition constant 0.4466) are *global*, hard-coded in `models.py`, and applied identically to all 171 galaxies. |

**None of the three models in this repository have any per-galaxy free
parameter.** This is intentional and is the fairest possible comparison:
all three take the same measured per-galaxy inputs (R, V_gas, V_disk,
V_bul, R_HI, M_bar) and apply a fixed global formula.

## How this differs from how dark matter halo fits are usually compared

This is the comparison that matters for the "do you need dark matter"
question, and it is NOT the comparison run in this repo (yet) — stated
here explicitly so nobody mistakes the MOND/RAR comparison above for a
dark-matter-halo comparison.

Standard particle dark matter halo profiles (NFW, Burkert, pseudo-isothermal,
and others used throughout the rotation-curve literature) are typically
fit **per galaxy**, with each galaxy getting its own halo normalization
and scale-radius parameters chosen specifically to make that galaxy's
curve match. Across a sample of N galaxies, this can mean 2N or 3N free
parameters total (commonly 2-3 free parameters *per galaxy*), compared to
the 0 *per-galaxy* free parameters used by the CSC fixed law above.

**This repository does not yet include a galaxy-by-galaxy halo-fit
comparison.** Adding one is a natural next module: it would show CSC's
0-per-galaxy-parameter result against, e.g., an NFW fit that is allowed
2 free parameters per galaxy. The original CSC papers note (correctly,
and conservatively) that a per-galaxy halo fit can still win on raw
chi-squared for any individual galaxy simply because it has more
flexibility — that is an expected, well-known property of any model with
more free parameters, not evidence that the halo is physically real. The
right comparison, once that module exists, is not "which curve passes
closer to the points" but "does a fixed global law match as well as a
model with many more per-galaxy parameters" — and separately, "does a
collisionless particle halo's required profile actually predict the same
baryonic-mass and HI-radius scaling that CSC gets for free."

## How to verify this table yourself

Don't trust this table either. Check it against the code directly:

1. Open `module1_sparc/models.py`.
2. For each function (`v_baryon_squared`, `csc_v_predicted_squared`,
   `mond_v_predicted_squared`), look at its arguments. Every argument is
   either a measured per-galaxy quantity (passed in from the data) or a
   constant defined once at the top of the file.
3. Search the entire `module1_sparc/` folder for any `fit(`, `optimize(`,
   `curve_fit`, or similar fitting call applied per-galaxy. There isn't
   one — the CSC, MOND, and baryons-only predictions are each computed
   directly from the formula, once, for the whole sample at once. The
   only thing "fit" anywhere in this module is the optional linear
   regression in `module2_dwarf/` (not this module), which is fitting the
   *running exponent trend itself* — a single global trend across all
   galaxies, not a per-galaxy adjustment.

If you find a hidden per-galaxy adjustment anywhere in this code, that
would be a real, important bug — open an issue.
